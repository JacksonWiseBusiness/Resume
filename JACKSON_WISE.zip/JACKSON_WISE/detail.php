<?php
	//Jackson Wise
	//September 23rd, 2024 
	//ASE-230
	//The detail page of a resume website that incorporates multidimential arrays and php echo statements to dynamically display text on the webpage.
	//Each array in the multidimensional array corresponds to a different person, and their different resume elements. Each person is filled with associative or index arrays that corresponds to the to the information being used in the body
	//This detail page displays actual the information and dummy data for each member contained in the arrays. 
	//This is done by using the $_GET value for each person (based on the detail.php page index), allowing us to select one person from the array and displaying their data using for loops and echo statements.
	//I did this project individually, so the first array in $team (team[0]/one with name=>Jackson Wise) is the only one with real information, while the other 3 contain fake names and dummy data.
$team=[	//Data Mutlidimentional Array 
	[
		"name"=>"Jackson Wise", 
		"image"=>"assets/images/Jackson.jpg",
		"role"=>"Team leader",
		"desiredJob"=>"System Administrator",
		"email"=>"jacksonwise.business@gmail.com",
		"phone"=>"859-414-2345",
		"linkedin"=>"linkedin.com/in/jackson-wise-742a69214",
		"linkedinLink"=>"https://www.linkedin.com/in/jackson-wise-742a69214",
		"github"=>"github.com/JacksonWiseBusiness",
		"githubLink"=>"https://github.com/JacksonWiseBusiness",
		"website"=>"jacksonwisebio.com", //Website is madeup so no link
		"summary"=>"I'm a passionate Cybersecurity student with a strong foundation in linux/windows operating systems, security fundamentals, and data alogorithms and strcutures. My professional experience in retail has taught me essential communcation and problem-solving skills. I'm seeking an entry-level position to apply my skills, contribute to innovating projects, and grow my skills along side the company. Some fun facts about me: I'm double jointed in most of my joints, I'm canadian, and I have three dogs, a gecko, and a bunch of fish!",
		"education"=>[
			[
				"degree"=>"Seeking BSc in you",
				"university"=>"any university",
				"time"=>"2020 - Present",
			],
		],
		"awards"=>[
			[	
				"name"=>"President's Honors List",
				"description"=>"Student's who've earned a 4.0 GPA in a semester",
			],
		],
		"workExperience"=>[
			[
				"title"=>"Guest Service Advocate",
				"company"=>"Target",
				"time"=>"2021 - Present",
				"description"=>"As a guest advocate, I'm expected to ensure each and every customer that enters the store has the proper guest experience. My goal is to make shopping quick and easy for guests at the checklanes, guest services, gift registry, pick-up and drive up while ensuring exceptional quality",
				"achievements"=>[
					"Employee of the Month",
					"Trained and mentored dozens of new employees, leading to improved team performance and customer service.",
					"Continuously ensured weekly loyalty goals were met",
				],
				"technologies"=>[
					"Zebra Technologies",
					"POS Systems",
				],
			],
			[
				"title"=>"Landscaper",
				"company"=>"Self-Employed",
				"time"=>"2018 - 2020",
				"description"=>"As a self-employed landscaper, I was expected to handle my own networking to reach my services to clients. Once I managed to attain clients, I would use effective communication to tailor my services my client's lawncare specifications. I Performed regular maintenance tasks, such as mowing, trimming, pruning, and watering to ensure the appearance of lawns and gardens.",
				"achievements"=>[
					"Was able to manage 10 different client's lawns at a young age ",
					"Ensured customer satisfaction rating by delivering high-quality landscaping services and maintaining clear communication.",
				],
				"technologies"=>[
					"Social Media",
				],
			],
		],
		"languages"=>[
			[	
				"type"=>"English",
				"proficiency"=>"(Native)"
			],
		],
		"interests"=>[
			"Video games", "Movies/Shows", "Hiking", "Legos",
		],
		"mskills"=>[
			[
				'mskill' => "Problem-Solving",
                'progress' => 96
            ],
			[
				'mskill' => "Communication",
                'progress' => 96
            ],
            [
				'mskill' => "Adaptability",
                'progress' => 93
            ],
            [
				'mskill' => "Java",
                'progress' => 93
            ],
            [
				'mskill' => "Windows/Linux OS",
                'progress' => 90
            ],
		],
		"oskills"=>[
			"AWS", "Wireshark", "Autopsy", "VSCode", "MySQL", "Teamwork", "MISP", "Python",
		],
		"projects"=>[
			[
				"name"=>"Deep Space Fix - Text-Based Game",
				"image"=>"assets/images/project1.jpg",
				"description"=>"Deep Space Fix is a text-based game I created using python. In this game, you are an astronaunt who got stranded in space after an astroid hit your spacecraft. The goal of this game is to explore the ship to find the tools required to repair the damages.",
				"link"=>"N/A",
			],
			[
				"name"=>"Web Developers turned Critics",
				"image"=>"assets/images/project2.jpg",
				"description"=>"This is a website created using HTML/CSS/Javascript that allows the us, the web developer, to give our own reviews of movies we've recently seen. Users are also able to submit their own review score to add to the current score of the recent movie we've rated.",
				"link"=>"N/A",
			],
			[
				"name"=>"AWS Application Loadbalancer",
				"image"=>"assets/images/project3.jpg",
				"description"=>"I used AWS to create an application loadbalancer to balance the load of traffic to EC2 instances. It also had subnets in different avaiablility zones to allow for quickload times for users in these different zones.",
				"link"=>"N/A",
			]
		],
	],
	[
		"name"=>"Bob",
		"image"=>"assets/images/Bob.jpg",
		"role"=>"Team member",
		"desiredJob"=>"sodales malesuada tortor congue",
		"email"=>"bob@gmail.com",
		"phone"=>"123-456-7890",
		"linkedin"=>"linkedin.com/in/bob",
		"linkedinLink"=>"#",
		"github"=>"github.com/bob",
		"githubLink"=>"#",
		"website"=>"bob.com", 
		"summary"=>"I'm Bob! Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in lacinia ex, at ultrices nisi. Sed consequat id lacus eget tristique. Mauris sodales, urna aliquam vestibulum volutpat, augue nibh pellentesque enim, sed posuere mauris purus at tellus. Curabitur nec ante nec libero luctus vulputate vel non velit. Vestibulum sodales velit ut odio mattis, nec varius nisi rhoncus. Nullam id enim non metus volutpat tempor nec sed mi. Nulla dictum nunc non mauris porta sollicitudin. Proin at arcu urna. Integer sed scelerisque velit. Nam dictum nisl sit amet lorem porttitor elementum. Aliquam efficitur dictum libero a vehicula. Cras eu volutpat lectus, pulvinar dapibus libero. ",
		"workExperience"=>[
			[
				"title"=>"Orci varius natoque penatibus",
				"company"=>"auctor at",
				"time"=>"2019 - Present",
				"description"=>"Nam volutpat libero id enim euismod, non pretium ligula euismod. Donec porta est cursus nisi blandit finibus. ",
				"achievements"=>[
					"Donec porta est cursus nisi blandit finibus. Sed semper risus facilisis, tempor nisi eu, mattis lorem.",
					"Proin in turpis ut diam posuere ornare. Nulla vehicula diam ut aliquam tempor.",
					"Mauris eros tortor, gravida non lacus at, ultricies facilisis leo. Etiam id arcu lectus.",
				],
				"technologies"=>[
					"Etiam id arcu lectus.",
					"Cras et nisi quis turpis feugiat tempor eu ut eros.",
					"Mauris molestie porta mollis. I",
				],
			],
			[
				"title"=>"Morbi et neque scelerisque",
				"company"=>"Vivamus tempus",
				"time"=>"2017 - 2019",
				"description"=>"Nam volutpat libero id enim euismod, non pretium ligula euismod. Donec porta est cursus nisi blandit finibus. ",
				"achievements"=>[
					"Donec porta est cursus nisi blandit finibus. Sed semper risus facilisis, tempor nisi eu, mattis lorem.",
				],
				"technologies"=>[
					"Etiam id arcu lectus.",
					"Cras et nisi quis turpis feugiat tempor eu ut eros.",
				],
			],
			[
				"title"=>"Duis vitae",
				"company"=>"Quisque",
				"time"=>"2016 - 2017",
				"description"=>"Nam volutpat libero id enim euismod, non pretium ligula euismod. Donec porta est cursus nisi blandit finibus. ",
				"achievements"=>[
					"Proin in turpis ut diam posuere ornare. Nulla vehicula diam ut aliquam tempor.",
					"Mauris eros tortor, gravida non lacus at, ultricies facilisis leo. Etiam id arcu lectus.",
				],
				"technologies"=>[
					"Etiam id arcu lectus.",
					"Cras et nisi quis turpis feugiat tempor eu ut eros.",
					"Mauris molestie porta mollis. I",
				],
			],
		],
		"education" => [
			[
				"degree"=>"Donec vestibulum",
				"university"=>"ultricies",
				"time"=>"2016 - 2020",
			],
		],
		"awards"=>[
			[	
			"name"=>"Duis",
			"description"=>"Mauris molestie porta mollis.",
			],
		],
		"languages"=>[
			[	
				"type"=>"Lorem ipsum",
				"proficiency"=>"(Native)"
			],
		],
		"interests"=>[
			"Lorem", "ipsum", "consectetur",
		],
		"mskills"=>[
			[
				'mskill' => "Quisque",
                'progress' => 70
            ],
			[
				'mskill' => "auctor",
                'progress' => 90
            ],
            [
				'mskill' => "Praesent",
                'progress' => 80
            ],
		],
		"oskills"=>[
			"maximus", "Vivamus", "tortor", "pulvinar",
		],
		"projects"=>[
			[
				"name"=>"Morbi et neque scelerisque",
				"image"=>"assets/images/BobP1.jpg",
				"description"=>"Ut malesuada nibh quis diam luctus, et pretium mauris tempor. Aliquam ornare vel metus eget pharetra. ",
				"link"=>"N/A",
			],
			[
				"name"=>"Praesent ut volutpat quam",
				"image"=>"assets/images/BobP2.jpg",
				"description"=>"Fusce sit amet ex ex. Nunc interdum sagittis lorem, nec lacinia tortor dictum nec. Sed blandit erat quis ipsum finibus laoreet.",
				"link"=>"N/A",
			],
			[
				"name"=>"Sed ut feugiat leo.",
				"image"=>"assets/images/BobP3.jpg",
				"description"=>"Nullam porta hendrerit convallis. Quisque auctor at neque non auctor. Praesent lobortis dui ante, eu vulputate orci vulputate ut.",
				"link"=>"N/A",
			]
		],
	],
	[
		"name"=>"Maria",
		"image"=>"assets/images/Maria.jpg",
		"role"=>"Team member",
		"desiredJob"=>"sodales malesuada tortor congue",
		"email"=>"maria@gmail.com",
		"phone"=>"123-456-7890",
		"linkedin"=>"linkedin.com/in/maria",
		"linkedinLink"=>"#",
		"github"=>"github.com/maria",
		"githubLink"=>"#",
		"website"=>"maria.com", 
		"summary"=>"I'm Maria! Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in lacinia ex, at ultrices nisi. Sed consequat id lacus eget tristique. Mauris sodales, urna aliquam vestibulum volutpat, augue nibh pellentesque enim, sed posuere mauris purus at tellus. Curabitur nec ante nec libero luctus vulputate vel non velit. Vestibulum sodales velit ut odio mattis, nec varius nisi rhoncus. Nullam id enim non metus volutpat tempor nec sed mi. Nulla dictum nunc non mauris porta sollicitudin. Proin at arcu urna. Integer sed scelerisque velit. Nam dictum nisl sit amet lorem porttitor elementum. Aliquam efficitur dictum libero a vehicula. Cras eu volutpat lectus, pulvinar dapibus libero. ",
		"workExperience"=>[
			[
				"title"=>"Orci varius natoque penatibus",
				"company"=>"auctor at",
				"time"=>"2019 - Present",
				"description"=>"Nam volutpat libero id enim euismod, non pretium ligula euismod. Donec porta est cursus nisi blandit finibus. ",
				"achievements"=>[
					"Donec porta est cursus nisi blandit finibus. Sed semper risus facilisis, tempor nisi eu, mattis lorem.",
					"Proin in turpis ut diam posuere ornare. Nulla vehicula diam ut aliquam tempor.",
					"Mauris eros tortor, gravida non lacus at, ultricies facilisis leo. Etiam id arcu lectus.",
				],
				"technologies"=>[
					"Etiam id arcu lectus.",
					"Cras et nisi quis turpis feugiat tempor eu ut eros.",
					"Mauris molestie porta mollis. I",
				],
			],
		],
		"education" => [
			[
				"degree"=>"Donec vestibulum",
				"university"=>"ultricies",
				"time"=>"2016 - 2020",
			],
		],
		"awards"=>[
			[	
			"name"=>"Duis",
			"description"=>"Mauris molestie porta mollis.",
			],
		],
		"languages"=>[
			[	
				"type"=>"Lorem ipsum",
				"proficiency"=>"(Native)"
			],
		],
		"interests"=>[
			"Lorem", "ipsum", "consectetur",
		],
		"mskills"=>[
			[
				'mskill' => "Quisque",
                'progress' => 70
            ],
			[
				'mskill' => "auctor",
                'progress' => 90
            ],
            [
				'mskill' => "Praesent",
                'progress' => 80
            ],
            [
				'mskill' => "commodo",
                'progress' => 100
            ],
		],
		"oskills"=>[
			"dolor", "adipiscing", "Suspendisse", "maximus", "Vivamus", "tortor",
		],
		"projects"=>[
			[
				"name"=>"Morbi et neque scelerisque",
				"image"=>"assets/images/MariaP1.jpg",
				"description"=>"Ut malesuada nibh quis diam luctus, et pretium mauris tempor. Aliquam ornare vel metus eget pharetra. ",
				"link"=>"N/A",
			],
			[
				"name"=>"Praesent ut volutpat quam",
				"image"=>"assets/images/MariaP2.jpg",
				"description"=>"Fusce sit amet ex ex. Nunc interdum sagittis lorem, nec lacinia tortor dictum nec. Sed blandit erat quis ipsum finibus laoreet.",
				"link"=>"N/A",
			],
		],
	],
	[
		"name"=>"Doug",
		"image"=>"assets/images/Doug.jpg",
		"role"=>"Team member",
		"desiredJob"=>"sodales malesuada tortor congue",
		"email"=>"doug@gmail.com",
		"phone"=>"123-456-7890",
		"linkedin"=>"linkedin.com/in/doug",
		"linkedinLink"=>"#",
		"github"=>"github.com/doug",
		"githubLink"=>"#",
		"website"=>"doug.com", 
		"summary"=>"I'm Doug! Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in lacinia ex, at ultrices nisi. Sed consequat id lacus eget tristique. Mauris sodales, urna aliquam vestibulum volutpat, augue nibh pellentesque enim, sed posuere mauris purus at tellus. Curabitur nec ante nec libero luctus vulputate vel non velit. Vestibulum sodales velit ut odio mattis, nec varius nisi rhoncus. Nullam id enim non metus volutpat tempor nec sed mi. Nulla dictum nunc non mauris porta sollicitudin. Proin at arcu urna. Integer sed scelerisque velit. Nam dictum nisl sit amet lorem porttitor elementum. Aliquam efficitur dictum libero a vehicula. Cras eu volutpat lectus, pulvinar dapibus libero. ",
		"workExperience"=>[
			[
				"title"=>"Orci varius natoque penatibus",
				"company"=>"auctor at",
				"time"=>"2019 - Present",
				"description"=>"Nam volutpat libero id enim euismod, non pretium ligula euismod. Donec porta est cursus nisi blandit finibus. ",
				"achievements"=>[
					"Donec porta est cursus nisi blandit finibus. Sed semper risus facilisis, tempor nisi eu, mattis lorem.",
					"Proin in turpis ut diam posuere ornare. Nulla vehicula diam ut aliquam tempor.",
					"Mauris eros tortor, gravida non lacus at, ultricies facilisis leo. Etiam id arcu lectus.",
				],
				"technologies"=>[
					"Etiam id arcu lectus.",
					"Cras et nisi quis turpis feugiat tempor eu ut eros.",
					"Mauris molestie porta mollis. I",
				],
			],
			[
				"title"=>"Morbi et neque scelerisque",
				"company"=>"Vivamus tempus",
				"time"=>"2017 - 2019",
				"description"=>"Nam volutpat libero id enim euismod, non pretium ligula euismod. Donec porta est cursus nisi blandit finibus. ",
				"achievements"=>[
					"Donec porta est cursus nisi blandit finibus. Sed semper risus facilisis, tempor nisi eu, mattis lorem.",
				],
				"technologies"=>[
					"Etiam id arcu lectus.",
					"Cras et nisi quis turpis feugiat tempor eu ut eros.",
				],
			],
		],
		"education" => [
			[
				"degree"=>"Donec vestibulum",
				"university"=>"ultricies",
				"time"=>"2016 - 2020",
			],
		],
		"awards"=>[
			[	
			"name"=>"Duis",
			"description"=>"Mauris molestie porta mollis.",
			],
		],
		"languages"=>[
			[	
				"type"=>"Lorem ipsum",
				"proficiency"=>"(Native)"
			],
		],
		"interests"=>[
			"Lorem", "ipsum", "consectetur", "viverra"
		],
		"mskills"=>[
			[
				'mskill' => "Quisque",
                'progress' => 70
            ],
			[
				'mskill' => "auctor",
                'progress' => 90
            ],
        ],
		"oskills"=>[
			"dolor", "adipiscing", "Suspendisse", "maximus", "Vivamus", "tortor", "pulvinar",
		],
		"projects"=>[
			[
				"name"=>"Morbi et neque scelerisque",
				"image"=>"assets/images/DougP1.jpg",
				"description"=>"Ut malesuada nibh quis diam luctus, et pretium mauris tempor. Aliquam ornare vel metus eget pharetra. ",
				"link"=>"N/A",
			],
		],
	],
];
$index=$_GET["index"];
?>
<!DOCTYPE html>
<html lang="en"> 
<head>
    <title><?php echo $team[$index]["name"]; ?> Resume</title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $team[$index]["name"]; ?> resume">
    <meta name="author" content="<?php echo $team[$index]["name"]; ?>">    
    <link rel="shortcut icon" href="favicon.ico"> 
    
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
    
    <!-- FontAwesome JS-->
	<script defer src="assets/fontawesome/js/all.min.js"></script>
       
    <!-- Theme CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/pillar-1.css">


</head> 

<body>
    <article class="resume-wrapper text-center position-relative">
    	<?php /* Only the following line changed from the file in the previous assignment */ ?>
		<div class="mb-4"><a href="index.php" class="btn btn-primary">Back to index</a></div>
	    <div class="resume-wrapper-inner mx-auto text-start bg-white shadow-lg">
		    <header class="resume-header pt-4 pt-md-0">
			    <div class="row">
				    <div class="col-block col-md-auto resume-picture-holder text-center text-md-start">
				        <img class="picture" src="<?php echo $team[$index]["image"] ?>" alt="">
				    </div><!--//col-->
				    <div class="col">
					    <div class="row p-4 justify-content-center justify-content-md-between">
						    <div class="primary-info col-auto">
							    <h1 class="name mt-0 mb-1 text-white text-uppercase text-uppercase"><?php echo $team[$index]["name"]; ?></h1>
							    <div class="title mb-3"><?php echo $team[$index]["desiredJob"]; ?></div>
							    <ul class="list-unstyled">
								    <li class="mb-2"><a class="text-link" href="#"><i class="far fa-envelope fa-fw me-2" data-fa-transform="grow-3"></i><?php echo $team[$index]["email"]; ?></a></li>
								    <li><a class="text-link" href="#"><i class="fas fa-mobile-alt fa-fw me-2" data-fa-transform="grow-6"></i><?php echo $team[$index]["phone"]; ?></a></li>
							    </ul>
						    </div><!--//primary-info-->
						    <div class="secondary-info col-auto mt-2">
							    <ul class="resume-social list-unstyled">
					                <li class="mb-3"><a class="text-link" href="<?php echo $team[$index]["linkedinLink"]; ?>"><span class="fa-container text-center me-2"><i class="fab fa-linkedin-in fa-fw"></i></span><?php echo $team[$index]["linkedin"]; ?></a></li>
					                <li class="mb-3"><a class="text-link" href="<?php echo $team[$index]["githubLink"]; ?>"><span class="fa-container text-center me-2"><i class="fab fa-github-alt fa-fw"></i></span><?php echo $team[$index]["github"]; ?></a></li>
					                <li><a class="text-link" href="#"><span class="fa-container text-center me-2"><i class="fas fa-globe"></i></span><?php echo $team[$index]["website"]; ?></a></li>
							    </ul>
						    </div><!--//secondary-info-->
					    </div><!--//row-->
					    
				    </div><!--//col-->
			    </div><!--//row-->
		    </header>
		    <div class="resume-body p-5">
			    <section class="resume-section summary-section mb-5">
				    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3">Summary</h2>
				    <div class="resume-section-content">
					    <p class="mb-0"><?php echo $team[$index]["summary"]; ?></p>
				    </div>
			    </section><!--//summary-section-->
			    <div class="row">
				    <div class="col-lg-9">
					    <section class="resume-section experience-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3">Work Experience</h2>
						    <div class="resume-section-content">
							    <div class="resume-timeline position-relative">
							    <?php for($j=0;$j<count($team[$index]["workExperience"]);$j++){ ?>
								    <article class="resume-timeline-item position-relative pb-5">
									    <div class="resume-timeline-item-header mb-2">
										    <div class="d-flex flex-column flex-md-row">
										        <h3 class="resume-position-title font-weight-bold mb-1"><?php echo $team[$index]["workExperience"][$j]['title']; ?></h3>
										        <div class="resume-company-name ms-auto"><?php echo $team[$index]["workExperience"][$j]['company']; ?></div>
										    </div><!--//row-->
										    <div class="resume-position-time"><?php echo $team[$index]["workExperience"][$j]['time']; ?></div>
									    </div><!--//resume-timeline-item-header-->
									    <div class="resume-timeline-item-desc">
										    <p><?php echo $team[$index]["workExperience"][$j]['description']; ?></p>
										    <h4 class="resume-timeline-item-desc-heading font-weight-bold">Achievements:</h4>
										    <ul>
										    	<?php foreach ($team[$index]["workExperience"][$j]["achievements"] as $achievement) { ?>
        										<li><?php echo $achievement; ?></li> 
        										<?php } ?>
										    </ul>
										    <h4 class="resume-timeline-item-desc-heading font-weight-bold">Technologies used:</h4>
										    <ul class="list-inline">
										    	<?php foreach ($team[$index]["workExperience"][$j]["technologies"] as $technology) { ?>
        										<li class="list-inline-item"><span class="badge bg-secondary badge-pill"><?php echo $technology; ?> </span></li> 
        										<?php } ?>
										    </ul>
									    </div><!--//resume-timeline-item-desc-->

								    </article><!--//resume-timeline-item-->
								    <?php } ?>
						
							    </div><!--//resume-timeline-->
						
						    </div>
					    </section><!--//projects-section-->
				    </div>
				    <div class="col-lg-3">
					    <section class="resume-section skills-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3">Skills &amp; Tools</h2>
						    <div class="resume-section-content">
						        <div class="resume-skill-item">
							        <ul class="list-unstyled mb-4">
							        <?php for($j=0;$j<count($team[$index]["mskills"]);$j++){ ?>
								        <li class="mb-2">
								            <div class="resume-skill-name"><?php echo $team[$index]["mskills"][$j]["mskill"]; ?></div>
									        <div class="progress resume-progress">
											    <div class="progress-bar theme-progress-bar-dark" role="progressbar" style="width: <?php echo $team[$index]["mskills"][$j]["progress"]; ?>%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
								        </li>
									<?php } ?>
							        </ul>
						        </div><!--//resume-skill-item-->
						        <div class="resume-skill-item">
						            <h4 class="resume-skills-cat font-weight-bold">Others</h4>
						            <ul class="list-inline">
						            	<?php foreach ($team[$index]["oskills"] as $oskill) { ?>
        								<li class="list-inline-item"><span class="badge badge-light"><?php echo $oskill; ?></span></li> 
        								<?php } ?>
						            </ul>
						        </div><!--//resume-skill-item-->
						    </div><!--resume-section-content-->
					    </section><!--//skills-section-->
					    <section class="resume-section education-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3">Education</h2>
						    <div class="resume-section-content">
							    <ul class="list-unstyled">
							    <?php for($j=0;$j<count($team[$index]["education"]);$j++){ ?>
								    <li class="mb-2">
								        <div class="resume-degree font-weight-bold"><?php echo $team[$index]["education"][$j]["degree"]; ?></div>
								        <div class="resume-degree-org"><?php echo $team[$index]["education"][$j]["university"]; ?></div>
								        <div class="resume-degree-time"><?php echo $team[$index]["education"][$j]["time"]; ?></div>
								    </li>
								<?php } ?>
							    </ul>
						    </div>
					    </section><!--//education-section-->
					    <section class="resume-section reference-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3">Awards</h2>
						    <div class="resume-section-content">
							    <ul class="list-unstyled resume-awards-list">
							    <?php for($j=0;$j<count($team[$index]["awards"]);$j++){ ?>
								    <li class="mb-2 ps-4 position-relative">
								        <i class="resume-award-icon fas fa-trophy position-absolute" data-fa-transform="shrink-2"></i>
								        <div class="resume-award-name"><?php echo $team[$index]["awards"][$j]["name"]; ?></div>
								        <div class="resume-award-desc"><?php echo $team[$index]["awards"][$j]["description"]; ?></div>
								    </li>
								<?php } ?>
							    </ul>
						    </div>
					    </section><!--//interests-section-->
					    <section class="resume-section language-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3">Languages</h2>
						    <div class="resume-section-content">
							    <ul class="list-unstyled resume-lang-list">
							    <?php for($j=0;$j<count($team[$index]["languages"]);$j++){ ?>
									<li class="mb-2"><span class="resume-lang-name font-weight-bold"><?php echo $team[$index]["languages"][$j]["type"]; ?></span> <small class="text-muted font-weight-normal"><?php echo $resume[$index]["languages"][$j]["proficiency"]; ?></small></li>
							    <?php } ?>
							    </ul>
						    </div>
					    </section><!--//language-section-->
					    <section class="resume-section interests-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3">Interests</h2>
						    <div class="resume-section-content">
							    <ul class="list-unstyled">
								    <?php foreach ($team[$index]["interests"] as $interest) { ?>
        							<li class="mb-1"><?php echo $interest; ?></li> 
        							<?php } ?>
							    </ul>
						    </div>
					    </section><!--//interests-section-->
					    
				    </div>
			    </div><!--//row-->
				<section class="resume-section experience-section mb-5">
					<h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3">Projects</h2>
					<div class="row mt-4">
					<?php for($j=0;$j<count($team[$index]["projects"]);$j++){ ?>
						<div class="col-md-4">
							<div class="card">
								<img src="<?php echo $team[$index]["projects"][$j]["image"]; ?>" alt="Project <?= $j+1 ?>" class="card-img-top">
								<div class="card-body">
									<h5 class="card-title"><?php echo $team[$index]["projects"][$j]["name"]; ?></h5>
									<p class="card-text"><?php echo $team[$index]["projects"][$j]["description"]; ?></p>
									<a href="btn btn-outline-primary" href="#">Go to link</a>
								</div>
							</div>
						</div>
						<?php } ?>
					</div>
				</section><!--//projects-section-->
		    </div><!--//resume-body-->
		    
	    </div>
    </article> 

    
    <footer class="footer text-center pt-2 pb-5">
	    <!--/* This template is free as long as you keep the footer attribution link. If you'd like to use the template without the attribution link, you can buy the commercial license via our website: themes.3rdwavemedia.com Thank you for your support. :) */-->
        <small class="copyright">Designed with <span class="sr-only">love</span><i class="fas fa-heart"></i> by <?php echo $team[0]["name"]?></small>
    </footer>

    

</body>
</html> 

