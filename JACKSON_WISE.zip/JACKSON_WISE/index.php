<?php 	
	//Jackson Wise
	//September 23rd, 2024 
	//ASE-230
	//The index page of a resume website that incorporates multidimential arrays and php echo statements to dynamically display text on the webpage.
	//Each array in the multidimensional array corresponds to a different person, and their different resume elements. Each person is filled with associative or index arrays that corresponds to the to the information being used in the body
	//This index page contains information and dummy data for each member via a multidimenital array; followed by html that shows member cards for the member's name, role, and their profile link.
	//I did this project individually, so the first array in $team (team[0]/one with name=>Jackson Wise) is the only one with real information, while the other 3 contain fake names and dummy data.
$team=[	//Data Mutlidimentional Array 
	[
		"name"=>"Jackson Wise",
		"image"=>"assets/images/Jackson.jpg",
		"role"=>"Team leader",
		"desiredJob"=>"System Administrator",
		"email"=>"jacksonwise.business@gmail.com",
		"phone"=>"859-414-2345",
		"linkedin"=>"linkedin.com/in/jackson-wise-742a69214",
		"linkedinLink"=>"https://www.linkedin.com/in/jackson-wise-742a69214",
		"github"=>"github.com/JacksonWiseBusiness",
		"githubLink"=>"https://github.com/JacksonWiseBusiness",
		"website"=>"jacksonwisebio.com", //Website is madeup so no link
		"summary"=>"I'm a passionate Cybersecurity student with a strong foundation in linux/windows operating systems, security fundamentals, and data alogorithms and strcutures. My professional experience in retail has taught me essential communcation and problem-solving skills. I'm seeking an entry-level position to apply my skills, contribute to innovating projects, and grow my skills along side the company. Some fun facts about me: I'm double jointed in most of my joints, I'm canadian, and I have three dogs, a gecko, and a bunch of fish!",
		"education"=>[
			[
				"degree"=>"Seeking BSc in you",
				"university"=>"any university",
				"time"=>"2020 - Present",
			],
		],
		"awards"=>[
			[	
				"name"=>"President's Honors List",
				"description"=>"Student's who've earned a 4.0 GPA in a semester",
			],
		],
		"workExperience"=>[
			[
				"title"=>"Guest Service Advocate",
				"company"=>"Target",
				"time"=>"2021 - Present",
				"description"=>"As a guest advocate, I'm expected to ensure each and every customer that enters the store has the proper guest experience. My goal is to make shopping quick and easy for guests at the checklanes, guest services, gift registry, pick-up and drive up while ensuring exceptional quality",
				"achievements"=>[
					"Employee of the Month",
					"Trained and mentored dozens of new employees, leading to improved team performance and customer service.",
					"Continuously ensured weekly loyalty goals were met",
				],
				"technologies"=>[
					"Zebra Technologies",
					"POS Systems",
				],
			],
			[
				"title"=>"Landscaper",
				"company"=>"Self-Employed",
				"time"=>"2018 - 2020",
				"description"=>"As a self-employed landscaper, I was expected to handle my own networking to reach my services to clients. Once I managed to attain clients, I would use effective communication to tailor my services my client's lawncare specifications. I Performed regular maintenance tasks, such as mowing, trimming, pruning, and watering to ensure the appearance of lawns and gardens.",
				"achievements"=>[
					"Was able to manage 10 different client's lawns at a young age ",
					"Ensured customer satisfaction rating by delivering high-quality landscaping services and maintaining clear communication.",
				],
				"technologies"=>[
					"Social Media",
				],
			],
		],
		"languages"=>[
			[	
				"type"=>"English",
				"proficiency"=>"(Native)"
			],
		],
		"interests"=>[
			"Video games", "Movies/Shows", "Hiking", "Legos",
		],
		"mskills"=>[
			[
				'mskill' => "Problem-Solving",
                'progress' => 96
            ],
			[
				'mskill' => "Communication",
                'progress' => 96
            ],
            [
				'mskill' => "Adaptability",
                'progress' => 93
            ],
            [
				'mskill' => "Java",
                'progress' => 93
            ],
            [
				'mskill' => "Windows/Linux OS",
                'progress' => 90
            ],
		],
		"oskills"=>[
			"AWS", "Wireshark", "Autopsy", "VSCode", "MySQL", "Teamwork", "MISP", "Python",
		],
		"projects"=>[
			[
				"name"=>"Deep Space Fix - Text-Based Game",
				"image"=>"assets/images/project1.jpg",
				"description"=>"Deep Space Fix is a text-based game I created using python. In this game, you are an astronaunt who got stranded in space after an astroid hit your spacecraft. The goal of this game is to explore the ship to find the tools required to repair the damages.",
				"link"=>"N/A",
			],
			[
				"name"=>"Web Developers turned Critics",
				"image"=>"assets/images/project2.jpg",
				"description"=>"This is a website created using HTML/CSS/Javascript that allows the us, the web developer, to give our own reviews of movies we've recently seen. Users are also able to submit their own review score to add to the current score of the recent movie we've rated.",
				"link"=>"N/A",
			],
			[
				"name"=>"AWS Application Loadbalancer",
				"image"=>"assets/images/project3.jpg",
				"description"=>"I used AWS to create an application loadbalancer to balance the load of traffic to EC2 instances. It also had subnets in different avaiablility zones to allow for quickload times for users in these different zones.",
				"link"=>"N/A",
			]
		],
	],
	[
		"name"=>"Bob",
		"image"=>"assets/images/Bob.jpg",
		"role"=>"Team member",
		"desiredJob"=>"sodales malesuada tortor congue",
		"email"=>"bob@gmail.com",
		"phone"=>"123-456-7890",
		"linkedin"=>"linkedin.com/in/bob",
		"linkedinLink"=>"#",
		"github"=>"github.com/bob",
		"githubLink"=>"#",
		"website"=>"bob.com",
		"summary"=>"I'm Bob! Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in lacinia ex, at ultrices nisi. Sed consequat id lacus eget tristique. Mauris sodales, urna aliquam vestibulum volutpat, augue nibh pellentesque enim, sed posuere mauris purus at tellus. Curabitur nec ante nec libero luctus vulputate vel non velit. Vestibulum sodales velit ut odio mattis, nec varius nisi rhoncus. Nullam id enim non metus volutpat tempor nec sed mi. Nulla dictum nunc non mauris porta sollicitudin. Proin at arcu urna. Integer sed scelerisque velit. Nam dictum nisl sit amet lorem porttitor elementum. Aliquam efficitur dictum libero a vehicula. Cras eu volutpat lectus, pulvinar dapibus libero. ",
		"workExperience"=>[
			[
				"title"=>"Orci varius natoque penatibus",
				"company"=>"auctor at",
				"time"=>"2019 - Present",
				"description"=>"Nam volutpat libero id enim euismod, non pretium ligula euismod. Donec porta est cursus nisi blandit finibus. ",
				"achievements"=>[
					"Donec porta est cursus nisi blandit finibus. Sed semper risus facilisis, tempor nisi eu, mattis lorem.",
					"Proin in turpis ut diam posuere ornare. Nulla vehicula diam ut aliquam tempor.",
					"Mauris eros tortor, gravida non lacus at, ultricies facilisis leo. Etiam id arcu lectus.",
				],
				"technologies"=>[
					"Etiam id arcu lectus.",
					"Cras et nisi quis turpis feugiat tempor eu ut eros.",
					"Mauris molestie porta mollis. I",
				],
			],
			[
				"title"=>"Morbi et neque scelerisque",
				"company"=>"Vivamus tempus",
				"time"=>"2017 - 2019",
				"description"=>"Nam volutpat libero id enim euismod, non pretium ligula euismod. Donec porta est cursus nisi blandit finibus. ",
				"achievements"=>[
					"Donec porta est cursus nisi blandit finibus. Sed semper risus facilisis, tempor nisi eu, mattis lorem.",
				],
				"technologies"=>[
					"Etiam id arcu lectus.",
					"Cras et nisi quis turpis feugiat tempor eu ut eros.",
				],
			],
			[
				"title"=>"Duis vitae",
				"company"=>"Quisque",
				"time"=>"2016 - 2017",
				"description"=>"Nam volutpat libero id enim euismod, non pretium ligula euismod. Donec porta est cursus nisi blandit finibus. ",
				"achievements"=>[
					"Proin in turpis ut diam posuere ornare. Nulla vehicula diam ut aliquam tempor.",
					"Mauris eros tortor, gravida non lacus at, ultricies facilisis leo. Etiam id arcu lectus.",
				],
				"technologies"=>[
					"Etiam id arcu lectus.",
					"Cras et nisi quis turpis feugiat tempor eu ut eros.",
					"Mauris molestie porta mollis. I",
				],
			],
		],
		"education" => [
			[
				"degree"=>"Donec vestibulum",
				"university"=>"ultricies",
				"time"=>"2016 - 2020",
			],
		],
		"awards"=>[
			[	
			"name"=>"Duis",
			"description"=>"Mauris molestie porta mollis.",
			],
		],
		"languages"=>[
			[	
				"type"=>"Lorem ipsum",
				"proficiency"=>"(Native)"
			],
		],
		"interests"=>[
			"Lorem", "ipsum", "consectetur",
		],
		"mskills"=>[
			[
				'mskill' => "Quisque",
                'progress' => 70
            ],
			[
				'mskill' => "auctor",
                'progress' => 90
            ],
            [
				'mskill' => "Praesent",
                'progress' => 80
            ],
		],
		"oskills"=>[
			"maximus", "Vivamus", "tortor", "pulvinar",
		],
		"projects"=>[
			[
				"name"=>"Morbi et neque scelerisque",
				"image"=>"assets/images/BobP1.jpg",
				"description"=>"Ut malesuada nibh quis diam luctus, et pretium mauris tempor. Aliquam ornare vel metus eget pharetra. ",
				"link"=>"N/A",
			],
			[
				"name"=>"Praesent ut volutpat quam",
				"image"=>"assets/images/BobP2.jpg",
				"description"=>"Fusce sit amet ex ex. Nunc interdum sagittis lorem, nec lacinia tortor dictum nec. Sed blandit erat quis ipsum finibus laoreet.",
				"link"=>"N/A",
			],
			[
				"name"=>"Sed ut feugiat leo.",
				"image"=>"assets/images/BobP3.jpg",
				"description"=>"Nullam porta hendrerit convallis. Quisque auctor at neque non auctor. Praesent lobortis dui ante, eu vulputate orci vulputate ut.",
				"link"=>"N/A",
			]
		],
	],
	[
		"name"=>"Maria",
		"image"=>"assets/images/Maria.jpg",
		"role"=>"Team member",
		"desiredJob"=>"sodales malesuada tortor congue",
		"email"=>"maria@gmail.com",
		"phone"=>"123-456-7890",
		"linkedin"=>"linkedin.com/in/maria",
		"linkedinLink"=>"#",
		"github"=>"github.com/maria",
		"githubLink"=>"#",
		"website"=>"maria.com", 
		"summary"=>"I'm Maria! Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in lacinia ex, at ultrices nisi. Sed consequat id lacus eget tristique. Mauris sodales, urna aliquam vestibulum volutpat, augue nibh pellentesque enim, sed posuere mauris purus at tellus. Curabitur nec ante nec libero luctus vulputate vel non velit. Vestibulum sodales velit ut odio mattis, nec varius nisi rhoncus. Nullam id enim non metus volutpat tempor nec sed mi. Nulla dictum nunc non mauris porta sollicitudin. Proin at arcu urna. Integer sed scelerisque velit. Nam dictum nisl sit amet lorem porttitor elementum. Aliquam efficitur dictum libero a vehicula. Cras eu volutpat lectus, pulvinar dapibus libero. ",
		"workExperience"=>[
			[
				"title"=>"Orci varius natoque penatibus",
				"company"=>"auctor at",
				"time"=>"2019 - Present",
				"description"=>"Nam volutpat libero id enim euismod, non pretium ligula euismod. Donec porta est cursus nisi blandit finibus. ",
				"achievements"=>[
					"Donec porta est cursus nisi blandit finibus. Sed semper risus facilisis, tempor nisi eu, mattis lorem.",
					"Proin in turpis ut diam posuere ornare. Nulla vehicula diam ut aliquam tempor.",
					"Mauris eros tortor, gravida non lacus at, ultricies facilisis leo. Etiam id arcu lectus.",
				],
				"technologies"=>[
					"Etiam id arcu lectus.",
					"Cras et nisi quis turpis feugiat tempor eu ut eros.",
					"Mauris molestie porta mollis. I",
				],
			],
		],
		"education" => [
			[
				"degree"=>"Donec vestibulum",
				"university"=>"ultricies",
				"time"=>"2016 - 2020",
			],
		],
		"awards"=>[
			[	
			"name"=>"Duis",
			"description"=>"Mauris molestie porta mollis.",
			],
		],
		"languages"=>[
			[	
				"type"=>"Lorem ipsum",
				"proficiency"=>"(Native)"
			],
		],
		"interests"=>[
			"Lorem", "ipsum", "consectetur",
		],
		"mskills"=>[
			[
				'mskill' => "Quisque",
                'progress' => 70
            ],
			[
				'mskill' => "auctor",
                'progress' => 90
            ],
            [
				'mskill' => "Praesent",
                'progress' => 80
            ],
            [
				'mskill' => "commodo",
                'progress' => 100
            ],
		],
		"oskills"=>[
			"dolor", "adipiscing", "Suspendisse", "maximus", "Vivamus", "tortor",
		],
		"projects"=>[
			[
				"name"=>"Morbi et neque scelerisque",
				"image"=>"assets/images/MariaP1.jpg",
				"description"=>"Ut malesuada nibh quis diam luctus, et pretium mauris tempor. Aliquam ornare vel metus eget pharetra. ",
				"link"=>"N/A",
			],
			[
				"name"=>"Praesent ut volutpat quam",
				"image"=>"assets/images/MariaP2.jpg",
				"description"=>"Fusce sit amet ex ex. Nunc interdum sagittis lorem, nec lacinia tortor dictum nec. Sed blandit erat quis ipsum finibus laoreet.",
				"link"=>"N/A",
			],
		],
	],
	[
		"name"=>"Doug",
		"image"=>"assets/images/Doug.jpg",
		"role"=>"Team member",
		"desiredJob"=>"sodales malesuada tortor congue",
		"email"=>"doug@gmail.com",
		"phone"=>"123-456-7890",
		"linkedin"=>"linkedin.com/in/doug",
		"linkedinLink"=>"#",
		"github"=>"github.com/doug",
		"githubLink"=>"#",
		"website"=>"doug.com", 
		"summary"=>"I'm Doug! Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in lacinia ex, at ultrices nisi. Sed consequat id lacus eget tristique. Mauris sodales, urna aliquam vestibulum volutpat, augue nibh pellentesque enim, sed posuere mauris purus at tellus. Curabitur nec ante nec libero luctus vulputate vel non velit. Vestibulum sodales velit ut odio mattis, nec varius nisi rhoncus. Nullam id enim non metus volutpat tempor nec sed mi. Nulla dictum nunc non mauris porta sollicitudin. Proin at arcu urna. Integer sed scelerisque velit. Nam dictum nisl sit amet lorem porttitor elementum. Aliquam efficitur dictum libero a vehicula. Cras eu volutpat lectus, pulvinar dapibus libero. ",
		"workExperience"=>[
			[
				"title"=>"Orci varius natoque penatibus",
				"company"=>"auctor at",
				"time"=>"2019 - Present",
				"description"=>"Nam volutpat libero id enim euismod, non pretium ligula euismod. Donec porta est cursus nisi blandit finibus. ",
				"achievements"=>[
					"Donec porta est cursus nisi blandit finibus. Sed semper risus facilisis, tempor nisi eu, mattis lorem.",
					"Proin in turpis ut diam posuere ornare. Nulla vehicula diam ut aliquam tempor.",
					"Mauris eros tortor, gravida non lacus at, ultricies facilisis leo. Etiam id arcu lectus.",
				],
				"technologies"=>[
					"Etiam id arcu lectus.",
					"Cras et nisi quis turpis feugiat tempor eu ut eros.",
					"Mauris molestie porta mollis. I",
				],
			],
			[
				"title"=>"Morbi et neque scelerisque",
				"company"=>"Vivamus tempus",
				"time"=>"2017 - 2019",
				"description"=>"Nam volutpat libero id enim euismod, non pretium ligula euismod. Donec porta est cursus nisi blandit finibus. ",
				"achievements"=>[
					"Donec porta est cursus nisi blandit finibus. Sed semper risus facilisis, tempor nisi eu, mattis lorem.",
				],
				"technologies"=>[
					"Etiam id arcu lectus.",
					"Cras et nisi quis turpis feugiat tempor eu ut eros.",
				],
			],
		],
		"education" => [
			[
				"degree"=>"Donec vestibulum",
				"university"=>"ultricies",
				"time"=>"2016 - 2020",
			],
		],
		"awards"=>[
			[	
			"name"=>"Duis",
			"description"=>"Mauris molestie porta mollis.",
			],
		],
		"languages"=>[
			[	
				"type"=>"Lorem ipsum",
				"proficiency"=>"(Native)"
			],
		],
		"interests"=>[
			"Lorem", "ipsum", "consectetur", "viverra"
		],
		"mskills"=>[
			[
				'mskill' => "Quisque",
                'progress' => 70
            ],
			[
				'mskill' => "auctor",
                'progress' => 90
            ],
        ],
		"oskills"=>[
			"dolor", "adipiscing", "Suspendisse", "maximus", "Vivamus", "tortor", "pulvinar",
		],
		"projects"=>[
			[
				"name"=>"Morbi et neque scelerisque",
				"image"=>"assets/images/DougP1.jpg",
				"description"=>"Ut malesuada nibh quis diam luctus, et pretium mauris tempor. Aliquam ornare vel metus eget pharetra. ",
				"link"=>"N/A",
			],
		],
	],
];

?>
<!DOCTYPE html>
<html lang="en"> 
<head>
    <title>Our amazing team</title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Jackson Wise's and Dummy Data's resume">
    <meta name="author" content="Jackson Wise">    
    <link rel="shortcut icon" href="favicon.ico"> 
    
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
    
    <!-- FontAwesome JS-->
	<script defer src="assets/fontawesome/js/all.min.js"></script>
       
    <!-- Theme CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/pillar-1.css">


</head> 

<body>
    <article class="resume-wrapper text-center position-relative">
	    <div class="resume-wrapper-inner mx-auto text-start bg-white shadow-lg">
			<h1 class="py-4 text-center">OUR AMAZING TEAM</h1>
			<?php for($i=0;$i<count($team);$i++) { ?>
		    <header class="resume-header mt-4 pt-4 pt-md-0">
			    <div class="row">
				    <div class="col-block col-md-auto resume-picture-holder text-center text-md-start">
				        <img class="picture" src="<?php echo $team[$i]["image"]; ?>" alt="">
				    </div><!--//col-->
				    <div class="col">
					    <div class="row p-4 justify-content-center justify-content-md-between">
						    <div class="primary-info col-auto">
							    <h1 class="name mt-0 mb-1 text-white text-uppercase text-uppercase"><?php echo $team[$i]["name"]; ?></h1>
							    <div class="title mb-3"><?php echo $team[$i]["role"]; ?></div>
								<a href="detail.php?index=<?= $i ?>" class="btn btn-secondary">See full profile</a>
						    </div><!--//primary-info-->
						    <div class="secondary-info col-auto mt-2">
						    </div><!--//secondary-info-->
					    </div><!--//row-->
					    
				    </div><!--//col-->
			    </div><!--//row-->
		    </header>
		<?php } ?>
		  
	    </div>
    </article> 
    
    <footer class="footer text-center pt-2 pb-5">
	    <!--/* This template is free as long as you keep the footer attribution link. If you'd like to use the template without the attribution link, you can buy the commercial license via our website: themes.3rdwavemedia.com Thank you for your support. :) */-->
        <small class="copyright">Designed with <span class="sr-only">love</span><i class="fas fa-heart"></i> by <?php echo $team[0]["name"]; ?></small>
    </footer>

    

</body>
</html> 
